document.write("<div style='margin:50px;text-align:center'>IE 10+ or a real browser is required.</div>")
document.execCommand('Stop')
