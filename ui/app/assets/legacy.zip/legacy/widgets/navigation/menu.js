define(["css!./menu", "css!../buttons/switch", "css!../buttons/radio"], function(){

  return ""

});
